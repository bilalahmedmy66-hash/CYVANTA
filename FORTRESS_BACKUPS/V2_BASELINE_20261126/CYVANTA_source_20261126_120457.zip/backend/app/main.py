from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.database.base import Base
from app.database.session import engine
from app.database.migrations import (
    ensure_ai_analysis_job_retry_column,
    ensure_active_defense_migrations,
    ensure_security_signals_migrations,
    ensure_platform_detection_migrations,
    ensure_simulation_dispatch_migrations,
    ensure_audit_log_migrations,
    ensure_login_rate_limit_migrations,
)
from app import models
from app.api import auth, assets, missions, executions, emergency_stops, asset_authorizations, organizations, intelligence_graph, ai, ai_jobs, platform_emergency_stops, platform_detection_findings, agent_intelligence


@asynccontextmanager
async def lifespan(app: FastAPI):
        Base.metadata.create_all(bind=engine)
        ensure_ai_analysis_job_retry_column(engine)
        ensure_active_defense_migrations(engine)
        ensure_security_signals_migrations(engine)
        ensure_platform_detection_migrations(engine)
        ensure_simulation_dispatch_migrations(engine)
        ensure_audit_log_migrations(engine)
        ensure_login_rate_limit_migrations(engine)
        yield


app = FastAPI(
    title=settings.app_name,
    description="Autonomous Cyber Operations Platform",
    version=settings.app_version,
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


app.include_router(auth.router, prefix="/api/v1")
app.include_router(organizations.router, prefix="/api/v1")
app.include_router(intelligence_graph.router, prefix="/api/v1")
app.include_router(agent_intelligence.router, prefix="/api/v1")
app.include_router(ai.router, prefix="/api/v1")
app.include_router(ai_jobs.router, prefix="/api/v1")
app.include_router(assets.router, prefix="/api/v1")
app.include_router(asset_authorizations.router, prefix="/api/v1")
app.include_router(missions.router)
app.include_router(executions.router)
app.include_router(emergency_stops.router, prefix="/api/v1")
app.include_router(platform_emergency_stops.router, prefix="/api/v1")
app.include_router(platform_detection_findings.router, prefix="/api/v1")


@app.get("/", tags=["System"])
def root():
    return {
        "application": settings.app_name,
        "message": "CYVANTA backend is running.",
        "documentation": "/docs",
    }


@app.get("/api/v1/health", tags=["System"])
def health_check():
    return {
        "status": "ok",
        "service": settings.app_name,
        "version": settings.app_version,
    }


@app.get("/api/v1/system/info", tags=["System"])
def system_info():
    return {
        "application": settings.app_name,
        "version": settings.app_version,
        "environment": settings.app_env,
    }





